#include <lvgl.h>
#include <TFT_eSPI.h>
#include <Wire.h>
#include <FT6236.h>  // dari Dustin Watts

#include "ui.h"  // hasil export dari SquareLine Studio

#define SCREEN_WIDTH  480
#define SCREEN_HEIGHT 320

TFT_eSPI tft = TFT_eSPI();
FT6236 ts = FT6236();

// Buffer LVGL
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[SCREEN_WIDTH * 20];
static lv_disp_drv_t disp_drv;
static lv_indev_drv_t indev_drv;

// Fungsi menggambar layar
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);

  tft.startWrite();
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors((uint16_t *)&color_p->full, w * h, true);
  tft.endWrite();

  lv_disp_flush_ready(disp);
}

// Fungsi baca sentuhan
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  if (ts.touched()) {
    TS_Point p = ts.getPoint();

    // FT6236: p.x = vertikal (Y), p.y = horizontal (X)
    int x = p.y;              // Horizontal = benar
    int y = SCREEN_HEIGHT - p.x; // Vertikal dibalik (mirror)

    // Batasi agar tidak keluar area
    x = constrain(x, 0, SCREEN_WIDTH - 1);
    y = constrain(y, 0, SCREEN_HEIGHT - 1);

    data->state = LV_INDEV_STATE_PR;
    data->point.x = x;
    data->point.y = y;

    Serial.print("Touch (fixed): ");
    Serial.print(x);
    Serial.print(", ");
    Serial.println(y);
  } else {
    data->state = LV_INDEV_STATE_REL;
  }
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  // Inisialisasi TFT
  tft.begin();
  tft.setRotation(1);  // Layar landscape kanan
  tft.fillScreen(TFT_BLACK);

  // Inisialisasi Touchscreen
  if (!ts.begin(40)) {
    Serial.println("Touchscreen tidak ditemukan");
  } else {
    Serial.println("Touchscreen ditemukan");
  }

  // Inisialisasi LVGL
  lv_init();
  lv_disp_draw_buf_init(&draw_buf, buf, NULL, SCREEN_WIDTH * 20);

  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = SCREEN_WIDTH;
  disp_drv.ver_res = SCREEN_HEIGHT;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  // Inisialisasi UI dari SquareLine
  ui_init();

  Serial.println("Setup selesai");
}

void loop() {
  lv_timer_handler();
  delay(1);  // Delay kecil wajib
}
