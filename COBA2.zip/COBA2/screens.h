#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *main;
    lv_obj_t *main_tab;
    lv_obj_t *bar;
    lv_obj_t *content;
    lv_obj_t *home;
    lv_obj_t *title_panel;
    lv_obj_t *title;
    lv_obj_t *qr_panel;
    lv_obj_t *text1;
    lv_obj_t *text2;
    lv_obj_t *qr;
    lv_obj_t *ec;
    lv_obj_t *ec_chart;
    lv_obj_t *ec_panel;
    lv_obj_t *arc_ec;
    lv_obj_t *value_ec;
    lv_obj_t *ph;
    lv_obj_t *ph_chart;
    lv_obj_t *ph_panel;
    lv_obj_t *arc_ph;
    lv_obj_t *value_ph_1;
    lv_obj_t *avg;
    lv_obj_t *avg_panel;
    lv_obj_t *result;
    lv_obj_t *ph_panel2;
    lv_obj_t *ph_last;
    lv_obj_t *ec_panel2;
    lv_obj_t *ec_last;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_MAIN = 1,
};

void create_screen_main();
void tick_screen_main();

void tick_screen_by_id(enum ScreensEnum screenId);
void tick_screen(int screen_index);

void create_screens();


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/