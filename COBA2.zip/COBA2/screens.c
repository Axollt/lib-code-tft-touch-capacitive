#include <string.h>

#include "screens.h"
#include "images.h"
#include "fonts.h"
#include "actions.h"
#include "vars.h"
#include "styles.h"
#include "ui.h"

#include <string.h>

objects_t objects;
lv_obj_t *tick_value_change_obj;

void create_screen_main() {
    void *flowState = getFlowState(0, 0);
    (void)flowState;
    lv_obj_t *obj = lv_obj_create(0);
    objects.main = obj;
    lv_obj_set_pos(obj, 0, 0);
    lv_obj_set_size(obj, 480, 320);
    {
        lv_obj_t *parent_obj = obj;
        {
            // main tab
            lv_obj_t *obj = lv_tabview_create(parent_obj, LV_DIR_LEFT, 60);
            objects.main_tab = obj;
            lv_obj_set_pos(obj, 0, 0);
            lv_obj_set_size(obj, 480, 320);
            {
                lv_obj_t *parent_obj = obj;
                {
                    // bar
                    lv_obj_t *obj = lv_tabview_get_tab_btns(parent_obj);
                    objects.bar = obj;
                    lv_obj_set_style_bg_color(obj, lv_color_hex(0xff4bd378), LV_PART_ITEMS | LV_STATE_CHECKED);
                    lv_obj_set_style_border_color(obj, lv_color_hex(0xff4bd378), LV_PART_ITEMS | LV_STATE_CHECKED);
                    lv_obj_set_style_text_color(obj, lv_color_hex(0xff4bd378), LV_PART_ITEMS | LV_STATE_CHECKED);
                }
                {
                    // content
                    lv_obj_t *obj = lv_tabview_get_content(parent_obj);
                    objects.content = obj;
                    {
                        lv_obj_t *parent_obj = obj;
                        {
                            // home
                            lv_obj_t *obj = lv_tabview_add_tab(lv_obj_get_parent(parent_obj), "HOME");
                            objects.home = obj;
                            {
                                lv_obj_t *parent_obj = obj;
                                {
                                    // TITLE PANEL
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.title_panel = obj;
                                    lv_obj_set_pos(obj, 2, -8);
                                    lv_obj_set_size(obj, 382, 49);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // TITLE
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.title = obj;
                                            lv_obj_set_pos(obj, 105, -8);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_obj_set_style_text_font(obj, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_color(obj, lv_color_hex(0xff4bd378), LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_label_set_text(obj, "GREEN FERTILE");
                                        }
                                    }
                                }
                                {
                                    // QR PANEL
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.qr_panel = obj;
                                    lv_obj_set_pos(obj, 2, 53);
                                    lv_obj_set_size(obj, 382, 235);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // TEXT1
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.text1 = obj;
                                            lv_obj_set_pos(obj, 0, 1);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_AUTO, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_font(obj, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_color(obj, lv_color_hex(0xff59c47c), LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_label_set_text(obj, "SCAN MY GITHUB FOR LIBRARY AND DOCUMENTATION");
                                        }
                                        {
                                            // TEXT2
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.text2 = obj;
                                            lv_obj_set_pos(obj, 114, 169);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_obj_set_style_text_font(obj, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_color(obj, lv_color_hex(0xff5db863), LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_label_set_text(obj, "SUPPORTED BY :\n                                    COE GREEN TECH");
                                        }
                                        {
                                            // QR
                                            lv_obj_t *obj = lv_qrcode_create(parent_obj, 114, lv_color_hex(0xff0e2014), lv_color_hex(0xffe2f5fe));
                                            objects.qr = obj;
                                            lv_obj_set_pos(obj, 117, 32);
                                            lv_obj_set_size(obj, 114, 114);
                                            lv_qrcode_update(obj, "https://envox.eu/", 17);
                                            lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
                                        }
                                    }
                                }
                            }
                        }
                        {
                            // ec
                            lv_obj_t *obj = lv_tabview_add_tab(lv_obj_get_parent(parent_obj), "EC");
                            objects.ec = obj;
                            {
                                lv_obj_t *parent_obj = obj;
                                {
                                    // EC CHART
                                    lv_obj_t *obj = lv_chart_create(parent_obj);
                                    objects.ec_chart = obj;
                                    lv_obj_set_pos(obj, 73, 179);
                                    lv_obj_set_size(obj, 306, 106);
                                }
                                {
                                    // EC PANEL
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.ec_panel = obj;
                                    lv_obj_set_pos(obj, 73, 5);
                                    lv_obj_set_size(obj, 306, 139);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // ARC_EC
                                            lv_obj_t *obj = lv_arc_create(parent_obj);
                                            objects.arc_ec = obj;
                                            lv_obj_set_pos(obj, -12, -1);
                                            lv_obj_set_size(obj, 108, 102);
                                            lv_arc_set_range(obj, 0, 20000);
                                            lv_arc_set_value(obj, 1000);
                                            lv_arc_set_bg_start_angle(obj, 1);
                                            lv_arc_set_bg_end_angle(obj, 360);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_rounded(obj, false, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_color(obj, lv_color_hex(0xff2f3734), LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_rounded(obj, false, LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_color(obj, lv_color_hex(0xff4bd378), LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_top(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_bottom(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_left(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_right(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_color(obj, lv_color_hex(0xfffafafa), LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_row(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_bg_opa(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            {
                                                lv_obj_t *parent_obj = obj;
                                                {
                                                    // value_EC
                                                    lv_obj_t *obj = lv_label_create(parent_obj);
                                                    objects.value_ec = obj;
                                                    lv_obj_set_pos(obj, 34, 45);
                                                    lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                                    lv_label_set_text(obj, "Value");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        {
                            // ph
                            lv_obj_t *obj = lv_tabview_add_tab(lv_obj_get_parent(parent_obj), "PH");
                            objects.ph = obj;
                            {
                                lv_obj_t *parent_obj = obj;
                                {
                                    // PH CHART
                                    lv_obj_t *obj = lv_chart_create(parent_obj);
                                    objects.ph_chart = obj;
                                    lv_obj_set_pos(obj, 73, 179);
                                    lv_obj_set_size(obj, 306, 106);
                                    lv_obj_clear_flag(obj, LV_OBJ_FLAG_CLICKABLE);
                                }
                                {
                                    // PH PANEL
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.ph_panel = obj;
                                    lv_obj_set_pos(obj, 73, 5);
                                    lv_obj_set_size(obj, 306, 139);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // ARC_PH
                                            lv_obj_t *obj = lv_arc_create(parent_obj);
                                            objects.arc_ph = obj;
                                            lv_obj_set_pos(obj, -12, -1);
                                            lv_obj_set_size(obj, 108, 102);
                                            lv_arc_set_range(obj, 0, 20000);
                                            lv_arc_set_value(obj, 1000);
                                            lv_arc_set_bg_start_angle(obj, 1);
                                            lv_arc_set_bg_end_angle(obj, 360);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_rounded(obj, false, LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_color(obj, lv_color_hex(0xff2f3734), LV_PART_MAIN | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_rounded(obj, false, LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_color(obj, lv_color_hex(0xff4bd378), LV_PART_INDICATOR | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_top(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_bottom(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_left(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_right(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_arc_width(obj, 9, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_text_color(obj, lv_color_hex(0xfffafafa), LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_pad_row(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            lv_obj_set_style_bg_opa(obj, 0, LV_PART_KNOB | LV_STATE_DEFAULT);
                                            {
                                                lv_obj_t *parent_obj = obj;
                                                {
                                                    // value_ph_1
                                                    lv_obj_t *obj = lv_label_create(parent_obj);
                                                    objects.value_ph_1 = obj;
                                                    lv_obj_set_pos(obj, 34, 45);
                                                    lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                                    lv_label_set_text(obj, "Value");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        {
                            // avg
                            lv_obj_t *obj = lv_tabview_add_tab(lv_obj_get_parent(parent_obj), "AVG");
                            objects.avg = obj;
                            {
                                lv_obj_t *parent_obj = obj;
                                {
                                    // AVG PANEL
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.avg_panel = obj;
                                    lv_obj_set_pos(obj, 73, 179);
                                    lv_obj_set_size(obj, 306, 106);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // Result
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.result = obj;
                                            lv_obj_set_pos(obj, 112, 19);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_label_set_text(obj, "Result");
                                        }
                                    }
                                }
                                {
                                    // PH PANEL2
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.ph_panel2 = obj;
                                    lv_obj_set_pos(obj, 236, 5);
                                    lv_obj_set_size(obj, 143, 139);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // ph_last
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.ph_last = obj;
                                            lv_obj_set_pos(obj, 21, 44);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_label_set_text(obj, "pH Value");
                                        }
                                    }
                                }
                                {
                                    // EC PANEL2
                                    lv_obj_t *obj = lv_obj_create(parent_obj);
                                    objects.ec_panel2 = obj;
                                    lv_obj_set_pos(obj, 73, 5);
                                    lv_obj_set_size(obj, 143, 139);
                                    {
                                        lv_obj_t *parent_obj = obj;
                                        {
                                            // EC_last
                                            lv_obj_t *obj = lv_label_create(parent_obj);
                                            objects.ec_last = obj;
                                            lv_obj_set_pos(obj, 22, 44);
                                            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
                                            lv_label_set_text(obj, "EC Value");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    tick_screen_main();
}

void tick_screen_main() {
    void *flowState = getFlowState(0, 0);
    (void)flowState;
}


static const char *screen_names[] = { "Main" };
static const char *object_names[] = { "main", "main_tab", "bar", "content", "home", "title_panel", "title", "qr_panel", "text1", "text2", "qr", "ec", "ec_chart", "ec_panel", "arc_ec", "value_ec", "ph", "ph_chart", "ph_panel", "arc_ph", "value_ph_1", "avg", "avg_panel", "result", "ph_panel2", "ph_last", "ec_panel2", "ec_last" };


typedef void (*tick_screen_func_t)();
tick_screen_func_t tick_screen_funcs[] = {
    tick_screen_main,
};
void tick_screen(int screen_index) {
    tick_screen_funcs[screen_index]();
}
void tick_screen_by_id(enum ScreensEnum screenId) {
    tick_screen_funcs[screenId - 1]();
}

void create_screens() {
    eez_flow_init_screen_names(screen_names, sizeof(screen_names) / sizeof(const char *));
    eez_flow_init_object_names(object_names, sizeof(object_names) / sizeof(const char *));
    
    lv_disp_t *dispp = lv_disp_get_default();
    lv_theme_t *theme = lv_theme_default_init(dispp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED), true, LV_FONT_DEFAULT);
    lv_disp_set_theme(dispp, theme);
    
    create_screen_main();
}
